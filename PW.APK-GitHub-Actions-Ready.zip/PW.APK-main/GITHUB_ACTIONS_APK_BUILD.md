# GitHub Actions Debug APK build

This repository now includes `.github/workflows/android-debug-apk.yml`.

- Push the project to the repository's default branch, or run **Actions → Build Debug APK → Run workflow**.
- The workflow builds `:app:assembleDebug`.
- It uploads `app-debug.apk` as a downloadable workflow artifact.
- On a push to the default branch, it also commits the generated `app-debug.apk` to the repository root.

If the workflow cannot push the APK, check **Settings → Actions → General → Workflow permissions** and enable read/write permissions.
